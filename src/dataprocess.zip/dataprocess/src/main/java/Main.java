

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    public static void main(String []args) throws IOException{
//        String idpath = "/home/ross/161.tar/commitid";
//        String filepath = "/home/ross/161.tar/branchhistory";//len is 40

//        String idpath = args[0];
        String filepath = args[0];//len is 40

        BufferedReader br = new BufferedReader(new FileReader(filepath));

        HashMap<String, LinkedList<String>> mymap = new HashMap<String, LinkedList<String>>();
//        ArrayDeque<String> result = new ArrayDeque<String>();
        String line;
        while((line = br.readLine())!=null){
//            myset.add(line);
            String [] ele = line.split(" ");
            if (mymap.containsKey(ele[1])) {
                LinkedList temp = mymap.get(ele[1]);
                temp.add(ele[0]+"-"+ele[2]);
            }
            else{
                LinkedList values = new LinkedList<String>();
                values.add(ele[0]+"-"+ele[2]);
                mymap.put(ele[1], values);
            }
        }

        br.close();

        Set keys = mymap.keySet();
        LinkedList<LinkedList<String>> values = new LinkedList<LinkedList<String>>();

        int n=0;

        int m=0;
        for (Object key : keys) {
            m++;
            System.out.print(key + ",");
            values.add(mymap.get(key));
            if (mymap.get(key).size()>n){
                n=mymap.get(key).size();
            }
        }

        System.out.println();

        int[] index= new int[m];

        for(int k=0;k<m;k++){
            index[k] = 0;
        }

        for (int i=0; i < n; i++){
            for (int j=0;j<m;j++){
                if (index[j] < values.get(j).size()&& i== Integer.parseInt(values.get(j).get(index[j]).split("-")[0])) {
                    System.out.print(values.get(j).get(index[j]).split("-")[1] + ",");
                    index[j]++;
//                    System.out.print(values.get(j).get(i) + ",");
                }
                else{
                    System.out.print(",");
                }
            }

            System.out.println();
        }


//        br = new BufferedReader(new FileReader(filepath));
//        String pattern_commit  = ".*(commit [a-z0-9]{40}).*";
//        Pattern p1 = Pattern.compile(pattern_commit);
//        String pattern_result = "^\\*(\\s+)(commit [a-z0-9]{40})";
//        Pattern p2 = Pattern.compile(pattern_result);
//        int i = 0;
//        while((line=br.readLine())!=null){
//            Matcher m1 = p1.matcher(line);
//            Matcher m2 = p2.matcher(line);
//            if(m2.find()) {
//                while(!result.isEmpty()){
//                    System.out.println(result.remove().substring(7));
//                    System.out.println(m2.group(2).substring(7));
//                }
//            }
//
//            if(m1.find() && myset.contains(m1.group(1))){
//                result.add(m1.group(1));
//            }
//        }
//
    }
}