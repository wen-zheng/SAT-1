

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    public static void main(String []args) throws IOException{
//        String idpath = "/home/ross/161.tar/commitid";
//        String filepath = "/home/ross/161.tar/branchhistory";//len is 40

        String idpath = args[0];
        String filepath = args[1];//len is 40

        BufferedReader br = new BufferedReader(new FileReader(idpath));

        HashSet<String> myset = new HashSet<String>();
        ArrayDeque<String> result = new ArrayDeque<String>();
        String line;
        while((line = br.readLine())!=null){
            myset.add(line);
        }

        br.close();

        br = new BufferedReader(new FileReader(filepath));
        String pattern_commit  = ".*(commit [a-z0-9]{40}).*";
        Pattern p1 = Pattern.compile(pattern_commit);
        String pattern_result = "^\\*(\\s+)(commit [a-z0-9]{40})";
        Pattern p2 = Pattern.compile(pattern_result);
        int i = 0;
        while((line=br.readLine())!=null){
            Matcher m1 = p1.matcher(line);
            Matcher m2 = p2.matcher(line);
            if(m2.find()) {
                while(!result.isEmpty()){
                    System.out.println(result.remove().substring(7));
                    System.out.println(m2.group(2).substring(7));
                }
            }

            if(m1.find() && myset.contains(m1.group(1))){
                result.add(m1.group(1));
            }
        }

    }
}