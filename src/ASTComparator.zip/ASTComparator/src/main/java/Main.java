import java.util.HashMap;
import java.io.File;
import java.nio.file.*;

public class Main {

    private static double getSimilarity(String path1, String path2) {
        Ast ast1 = Ast.fromFile(path1);
        Ast ast2 = Ast.fromFile(path2);
        double similarity = ast1.similarityTo(ast2);
        return similarity;
    }

//    public static void main(String[] args) {
//        if(args.length==2) {
//            String path1 = args[0];
//            String path2 = args[1];
//
//        }
//        else{
//            System.out.printf("error\n");
//            System.exit(1);
//        }
//
//    }

    public static final HashMap<String, String> PATHS = new HashMap<String, String>() {
        {
            put("person", "/home/ross/IdeaProjects/ASTComparator/src/main/res/Person.java");
            put("student", "/home/ross/IdeaProjects/ASTComparator/src/main/res/Student.java");
            put("undergraduate", "/home/ross/IdeaProjects/ASTComparator/src/main/res/UnderGraduate.java");
            put("graduate", "/home/ross/IdeaProjects/ASTComparator/src/main/res/Graduate.java");
        }
    };

    public static void main(String[] args) throws Exception{
        getFile(args[0]);
        String commit_time = args[2];
        for(int i=0;i<index;i++){
            String strPath1 = args[0]+Filename[i];
            String strPath2 = args[1]+Filename[i];

            String []temp1 = strPath1.split("/");
            String filename1 = temp1[temp1.length-1];

            if(!Files.exists(Paths.get(strPath2))) {
                System.out.printf( "%s %s: %.3f\n", commit_time, filename1, 0.0);
                continue;
            }

            double similarity = getSimilarity(strPath1, strPath2);
            System.out.printf("%s %s: %.3f\n", commit_time, filename1, similarity);
        }
    }

    public static void getJavaFile(String Dir){
        if(Dir.endsWith(".java")){
            Filename[index++] = Dir;
            return;
        }
        File f = new File(Dir);
        if(f.isDirectory()){
            String[] filenames =f.list();
            for(int i=0;i<filenames.length;i++){
                if( !(filenames[i].compareTo(".")==0 || filenames[i].compareTo("..")==0) ){
                    getJavaFile(Dir+"/"+filenames[i]);
                }
            }
        }
    }

    public static void getFile(String dir){
        getJavaFile(dir);
        for(int i=0;i<index;i++){
            Filename[i] = Filename[i].substring(dir.length());
        }
    }

    static String[] Filename = new String[1000];
    static int index = 0;
}