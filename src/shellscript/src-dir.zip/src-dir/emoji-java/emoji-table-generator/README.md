# emoji-table-genrator

This is just a "quick'n'dirty" project to generate a markdown table with all the emojis.

It is used for the table in the top level README :)
